## Infrastructure

This folder contains:
- User auth services and handlers
- Communication models which used to make it easier to retrieve URL parameters.
- Extension methods and mapping extension methods
