namespace Notalone.API.Models
{
    public interface IEntity
    {
        Guid Id { get; }
    }
}