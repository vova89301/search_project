namespace Notalone.API.Models;

public class DatabaseSettings
{
    public bool? PersistData { get; set; }
    public string? ConnectionString { get; set; }
}