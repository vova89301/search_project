// TODO: remove and replace with another solution
export class BasicAuthUser {
    username?: string;
    password?: string;
    authdata?: string;
}