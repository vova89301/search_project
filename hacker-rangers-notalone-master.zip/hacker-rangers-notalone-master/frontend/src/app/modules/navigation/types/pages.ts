import {MuiPage, MuiPageGroup} from '../interfaces/page';

export type MuiPages = ReadonlyArray<MuiPage | MuiPageGroup>;
