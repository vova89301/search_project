import {Injectable} from '@angular/core';
import {AbstractTuiPortalService} from '@taiga-ui/cdk';

@Injectable({
    providedIn: `root`,
})
export class CustomPortalService extends AbstractTuiPortalService {}
