import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mui-version-manager',
  templateUrl: './version-manager.component.html',
  styleUrls: ['./version-manager.component.less']
})
export class VersionManagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
