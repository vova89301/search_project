export const APP_NAME: string = "notalone";
