import {ViewEncapsulation} from '@angular/core';

export const encapsulation = ViewEncapsulation.ShadowDom;
