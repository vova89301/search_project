import {ChangeDetectionStrategy} from '@angular/core';

export const changeDetection = ChangeDetectionStrategy.OnPush;
