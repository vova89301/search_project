export const environment = {
  production: true,
  workspaceApiUrl: "https://localhost:5001"
};
