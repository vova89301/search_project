export const environment = {
  production: true,
  workspaceApiUrl: "https://notaloneapi.nakodeelee.ru"
};
